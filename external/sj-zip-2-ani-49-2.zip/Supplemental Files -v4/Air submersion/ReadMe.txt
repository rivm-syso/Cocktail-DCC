                          Air Submersion

This folder contains the age and sex specific monoenergetic dose rate
coefficients (nSv h-1 Bq-1 m3) for photon and electron emissions within
a semi-infinite cloud. Coefficients are tabulated at 25 energies for 29 
tissues of the body. The file naming convention identifies the radiation
and subject. For example, the file "Air_electron_00F.txt" addresses 
electrons irradiation of a newborn female (00F) while "Air_photon_AM.txt"
addresses photon irradiation of the adult male (AM).

The files "Air_electron_EffectiveDose.txt" and "Air_photon_EffectiveDose.txt" 
tabulate the age-specific effective dose rate coefficients for electron and
photon emissions, respectively. The "Air_photon_EffectiveDose.txt" file also
tabulated the operational quantities ambient dose equivalent rate and air 
kerma rate.

This folder contains also the nuclide, gender- and age-specific organ 
equivalent and effective dose rate coefficients for the 1,252 radionuclides
of ICRP Publication 107. The tabulations also include the operational 
quantities ambient dose equivalent and air kerma coefficients. The nuclide-
specific dose coefficient rates were computed on the basis of the evaluated
dose-rate coefficients for monoenergetic photons and electrons by 
interpolation in a log-linear space.