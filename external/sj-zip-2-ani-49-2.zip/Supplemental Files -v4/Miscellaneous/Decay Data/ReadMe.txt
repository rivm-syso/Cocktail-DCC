
               ICRP 107 Nuclear Decay Data Files

The nuclide specific dose rate coefficients were computed using the nuclear
decay data of ICRP Publication 107. The three data files of that publication
used in these calculations are archived in this folder. These files are
formatted direct-access files; each record being of fixed length and includes
a carriage return and line feed. The length of the records, less the carriage
return and line feed, for each files is listed below.

    Length and Numner of Records Data Files
    File            Length          Number 
    ---------------------------------------
   ICRP-07.NDX       226              1,253
   ICRP-07.RAD        29            455,625
   ICRP-07.BET        17            111,325
   ----------------------------------------
   Length does not include carriage return
   and line feed.

See ICRP Publication 107 for additional information.
