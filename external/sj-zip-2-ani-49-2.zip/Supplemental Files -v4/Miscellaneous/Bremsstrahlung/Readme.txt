                            Bremsstrahlung

This folder contains the bremsstralung spectra for the beta emitters of
ICRP Publication 107 as they slow down in air, water, and the soil. The
spectra are tabulated for photons of 10 keV and higher.  The record with
the nuclide name also indicates the number of energies tabulated.
                 
