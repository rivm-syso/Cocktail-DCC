 Soil Planar Source at Specific Depths Expressed as Mean Free Paths of Photons

This folder contains the age and sex specific monoenergetic dose rate
coefficients (nSv h-1 Bq-1 m2) for photon emissions from planar sources 
at specific depths in the soil expressed as mean free paths (mfp) of photons 
emitted in the soil. Coefficients are tabulated at 25 energies for 29 tissues 
of the body. The source planes are at depths of 0.0, 0.2, 1.0, 2.5 and 4 mfp. 
Each depth serves as a subfolder.

For a surface source (0.0 mfp) the folder contains the age and sex specific 
monoenergetic dose rate coefficients (nSv h-1 Bq-1 m2) for electron emissions, 
tabulated at 25 energies for 29 tissues of the body. 

The file naming convention identifies the radiation and subject. For example,
the file "Soil_photon_00F.txt" addresses photon irradiation of a newborn 
female; "Soil_photon_AF.txt addresses an adult female (AF).

The files "Soil_photon_EffectiveDose.txt" in each subfolder tabulates the
age-specific effective dose rate coefficients for photon emissions. The 
file also includes the operational quantities ambient dose equivalent rate
and air kerma rate.

The files "Soil_electron_EffectiveDose.txt" in the 0.0 mfp folder tabulates 
the age-specific effective dose rate coefficients for electron emissions for 
a surface source.
