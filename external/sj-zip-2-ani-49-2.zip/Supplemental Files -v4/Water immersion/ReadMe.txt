                          Water Immersion

This folder contains the age and sex specific monoenergetic dose rate
coefficients (nSv h-1 Bq-1 m3) for photon and electron emissions in
an infinite water body within which the subject is immersed. Coefficients
are tabulated at 25 energies for 29 tissues of the body. The file naming
convention identifies the radiation and subject. For example, the file 
"Water_electron_00F.txt" addresses electrons irradiation of a newborn female
(00F) while "Water_photon_AM.txt" addresses photon irradiation of the adult
male (AM).

The files "Water_electron_EffectiveDose.txt" and "Water_photon_EffectiveDose.txt" 
tabulate the age-specific effective dose rate coefficients for electron and
photon emissions, respectively.

This folder contains also the nuclide, gender- and age-specific organ equivalent 
and effective dose rate coefficients for the 1,252 radionuclides of ICRP 
Publication 107. These were computed on the basis of the organ absorbed dose-rate
coefficients for monoenergetic photons and electrons by interpolation in a 
log-linear space.

